import React from 'react'
import Menu from "../../components/Menu/Menu.jsx";

function Dashboard() {
  return (
    <>
      <Menu />
      <h1 className="font-medium text-[20px] ml-6 mt-6">Hey you made it to the dashboard!</h1>
    </>
  )
}

export default Dashboard