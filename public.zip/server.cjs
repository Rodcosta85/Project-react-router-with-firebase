const express = require('express');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = 5000;

// Middleware to parse JSON bodies
app.use(express.json());

// Path to the users.json file
const usersFilePath = path.join(__dirname, 'users.json');

// Route to get all users
app.get('/users', (req, res) => {
  const users = JSON.parse(fs.readFileSync(usersFilePath, 'utf8'));
  res.json(users);
});

// Route to add a new user
app.post('/add-user', (req, res) => {
  const newUser = req.body;
  const users = JSON.parse(fs.readFileSync(usersFilePath, 'utf8'));
  users.push(newUser);

  // Save updated users back to the file
  fs.writeFileSync(usersFilePath, JSON.stringify(users, null, 2));
  res.status(201).send('User added!');
});

// Start the server
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});